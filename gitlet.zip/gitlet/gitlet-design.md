# Gitlet Design Document

**Name**: Sandra Elena Zavala

## Classes and Data Structures

##SomeObj

###Fields

* ArrayList<String> untrackedFiles : contains the name of untracked files which are not commited and were removed if the wrong file was being committed.

* HashMap<File, String> trackedFiles: contains the name of file and the shacode of its contents.

* ArrayList<String> allCommits : a list of all the commits' id numbers

* HashMap<String, String> stageFiles : Record all the staged files with (fileName, idNumber).

* HashMap<File, Commit> fileCommits : Record all the CommitIDS with (File, commit).

* HashMap<Commit, String> hashCodes: Record all the CommitIDS with (Commit, commitIDs)

* HashMap<String, String> branches

* Record all the branches with ( branchName, CommitID).

* String _header: a variable that represents the master branch

* String _currentBranch : represents branch you are in.

* String currDirectory : represents current directory

##Commit

###Fields

* String *message*: This message is one that describes the most updated change that the user is making to the file which will then be transferred to the main repository.

* String *parent* : This is the parent of the current commit which is important since we have to keep track of the previous commits. This will help organize the hashmap of commits since you can pair a commit with its parent.

* Integer *ID*: includes the unique integer ID number for the commit in order to have a different classification for each commit. This will avoid confusion when trying to find the most current commit.

*  Date date - time at which commit was created

* String [] commitParents: a list of Parents with their ID numbers

* HashMap <String,String> files: This hashmap saves the files in this commit along with their contents.

* HashMap <String, Commit> *commitIDs*: This hashmap stores the commit IDS which can be referenced in order to check if a commit exists.

* HashMap<Commit, String> branches: Record all the branches with (Commit, branchName).

* ArrayList<String> allCommits: stores name of all commits

 
## Algorithms
###Main: 
It is the main working directory that holds all the files. This repository can be seen as a box that stores all information. The repository can have multiple branches that stem from the main working directory in order to have organized pathways.

###SomeObj: 
* add: This method saves changes to the current working branch in order to upload the files to the main repository. Add basically prepares the files to be uploaded to the repository.

* rm: This method marks a file for removal. This means it will not be seen as an old file in its next commit.

* status: It gives you a summary of all your commits with your most recent commit. It ensures there is no unnecessary merging if the main directory is already updated. It helps the user understand what commits have been done previous in order to avoid unnecessary commits. The different ID numbers for each commit will help differentiate between commits. 

* init : this initializes the gitlet directory

* commit : creates a commit object from the variables passed, staging files and tracked files 

* log : displays the ancestry of the current commit essentially

* global-log :  shows all the commits

* checkout : finding the relevant commit and checking out the file

* getCommit() :get file path from commit ID

*find : will find a commit based on a message

##Commit:
* getMessage() : get message of commit

* getDate() : get timestamp of commit

* getParent() : get previous commit aka parent of commit

* getCommitID() : 

* HashMap<String, String> getFileID() : return map of file name as key and file commit ID number as the value

* ArrayList<String> getAllCommits() : returns a String array of all commit ID numbers


## Persistence
*Repository*
1. *checkout* ensures that you are updating the correct branch. For example, if three branches exist, you will need to choose which branch you want to commit to in order to have a running directory.
2. *add* allows you to save files to save documents before committing them to avoid losing changes locally
**Status**
1. To ensure changes have been saved, status allows the user to check current saved changes which are stored in a Hashmap.